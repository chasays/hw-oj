#include "IPAddressValid.h"
#include <string>
#include <vector>

using namespace std;

bool isIPAddressValid(const char* pszIPAddr)
{
	if (!pszIPAddr)
		return false;

	string ins(pszIPAddr);

	int s = 0, t = ins.size()-1;
	for (; s < ins.size() && ins[s] == ' '; s++);
	for (; t >= 0 && ins[t] == ' '; t--);
	if (s >= t)
		return false;

	string inst = ins.substr(s, t - s + 1);

	vector<string> sv;
	int i = 0;
	for (int n = 0, j = 0; n < 3 && i < inst.length(); n++) {
		i = inst.find('.', i);
		if (i == string::npos)
			return false;
		sv.push_back(inst.substr(j, i - j));
		j = ++i;
	}
	if (i < inst.length())
		sv.push_back(inst.substr(i, inst.length() - i));

	if (sv.size() != 4)
		return false;
	for (int i = 0; i < 4; i++) {
		const string &sss = sv[i];
		if (sss.empty())
			return false;
		if (sss[0] == '0' && sss.length() > 1)
			return false;
		int c = 0;
		for (int j = 0; j < sss.length(); j++) {
			if (sss[j] >= '0' && sss[j] <= '9') {
				c = c * 10 + (sss[j] - '0');
				continue;
			} else
				return false;
		}
		if (c > 255)
			return false;
	}

    return true;
}