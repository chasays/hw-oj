/******************************************************************************

Copyright (C), 2001-2012, Huawei Tech. Co., Ltd.

******************************************************************************
File Name     :
Version       :
Author        :
Created       : 2012/3
Last Modified :
Description   :
Function List :

History       :
1.Date        : 2012/3
Author      :
Modification: Created file

******************************************************************************/
#include <string>
#include <map>
using namespace std;

int GetBracketMatchingNum(int nNum)
{
    /*������ʵ�ֹ���*/

    return 0;
}