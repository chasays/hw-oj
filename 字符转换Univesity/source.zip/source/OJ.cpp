#include <stdlib.h>
#include "oj.h"
#include <string.h>
#include <stdio.h>



char* CharReplace(char* pSourceChar)
{
	char dictA[] = "E C F A J K L B D G H I V W Z Y M N O P Q R S T U X";
	char dictB[] = "e r w q t y g h b n u i o p s j k d l f a z x c v m";

	int len = strlen(pSourceChar);
	for (int i = 0; i < len; i++) {
		if (pSourceChar[i] >= 'A' && pSourceChar[i] <= 'Z')
			pSourceChar[i] = dictA[(pSourceChar[i] - 'A') * 2];
		else if (pSourceChar[i] >= 'a' && pSourceChar[i] <= 'z')
			pSourceChar[i] = dictB[(pSourceChar[i] - 'a') * 2];
	}
	char* pResultChar = pSourceChar;
	return pResultChar;
}