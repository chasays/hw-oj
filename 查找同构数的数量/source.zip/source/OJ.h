#ifndef __OJ_H__
#define __OJ_H__

int SearchSameConstructNum(int n);

#endif
