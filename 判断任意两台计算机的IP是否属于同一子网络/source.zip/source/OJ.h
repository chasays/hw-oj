#ifndef __OJ_H__
#define __OJ_H__

int IsSameSubNetwork(char * pcIp1, char * pcIp2, char * pcSubNetworkMask);

#endif
