/******************************************************************************

  Copyright (C), 2001-2011, Huawei Tech. Co., Ltd.

 ******************************************************************************
  File Name     : 
  Version       : 
  Author        : 
  Created       : 2012/03/12
  Last Modified :
  Description   : 
  Function List :
              
  History       :
  1.Date        : 2012/03/12
    Author      : 
    Modification: Created file

******************************************************************************/
#include <stdlib.h>

#define MAXSIZE 5

struct strmatrix
{
	int rownum; /* ��ά�������� */
	int columnnum; /* ��ά�������� */
	int matrix[MAXSIZE][MAXSIZE];
};

void setnull(struct strmatrix *p)  /*���ÿ�*/
{
	p->rownum = 0;
	p->columnnum = 0;
	for (int i = 0; i < MAXSIZE; i++) {
		for (int j = 0; j < MAXSIZE; j++) {
			p->matrix[i][j] = 0;
		}
	}
}

int getelementnum(struct strmatrix *p)  /*��ȡ����Ԫ�ظ���*/
{
	int elementnum = 0;

	elementnum = p->rownum * p->columnnum;

	return elementnum;
}


int getxnum(struct strmatrix *p, int x) /*��������е���ĳ��ֵ��Ԫ�صĸ���*/
{
	int num = 0;

	for (int i = 0; i < p->rownum; i++) {
		for (int j = 0; j < p->columnnum; j++) {
			if (p->matrix[i][j] == x)
				num++;
		}
	}

	return num;
}

void insertrow(struct strmatrix *p,int i,int *x) /* ����1�� */
{
	if (i < 0 || i >= MAXSIZE || p->rownum == MAXSIZE)
		return;
	for (int r = p->rownum - 1; r >= i; r--) {
		for (int c = 0; c < p->columnnum; c++) {
			p->matrix[r + 1][c] = p->matrix[r][c];
			if (r == i)
				p->matrix[r][c] = x[c];
		}
	}
	p->rownum++;
}

void insertcolumn(struct strmatrix *p,int i,int *x) /* ����1�� */
{
	if (i < 0 || i >= MAXSIZE || p->columnnum == MAXSIZE)
		return;
	for (int c = p->columnnum - 1; c >= i; c--) {
		for (int r = 0; r < p->rownum; r++) {
			p->matrix[r][c + 1] = p->matrix[r][c];
			if (c == i)
				p->matrix[r][c] = x[r];
		}
	}
	p->columnnum++;
}


void matrixtrans(struct strmatrix *p) /* �������û� */
{
	if (p->rownum != p->columnnum)
		return;
	for (int i = 0; i < p->rownum; i++) {
		for (int j = 0; j < p->columnnum; j++) {
			if (i < j) {
				int tmp = p->matrix[i][j];
				p->matrix[i][j] = p->matrix[j][i];
				p->matrix[j][i] = tmp;
			}
		}
	}
}

void matrixwhirl(struct strmatrix *p) /* ������˳ʱ����ת90�� */
{
	if (p->rownum != p->columnnum)
		return;
	struct strmatrix q;
	q.rownum = p->columnnum;
	q.columnnum = p->rownum;
	for (int i = 0; i < q.rownum; i++) {
		for (int j = 0; j < q.columnnum; j++) {
			q.matrix[i][j] = p->matrix[p->rownum - 1 - j][i];
		}
	}
	p->rownum = q.rownum;
	p->columnnum = q.columnnum;
	for (int i = 0; i < q.rownum; i++) {
		for (int j = 0; j < q.columnnum; j++) {
			p->matrix[i][j] = q.matrix[i][j];
		}
	}
}

void matrixplus(struct strmatrix *plu, struct strmatrix *p, struct strmatrix *q) /* ����������� */
{
	if (p->rownum != q->rownum || p->columnnum != q->columnnum)
		return;
	plu->rownum = p->rownum;
	plu->columnnum = p->columnnum;
	for (int i = 0; i < p->rownum; i++) {
		for (int j = 0; j < p->columnnum; j++) {
			plu->matrix[i][j] = p->matrix[i][j] + q->matrix[i][j];
		}
	}
}

void matrixmultiply(struct strmatrix *mul, struct strmatrix *p, struct strmatrix *q) /* ����������� */
{
	if (p->columnnum != q->rownum)
		return;
	mul->rownum = p->rownum;
	mul->columnnum = q->columnnum;
	for (int i = 0; i < mul->rownum; i++) {
		for (int j = 0; j < mul->columnnum; j++) {
			mul->matrix[i][j] = 0;
			for (int k = 0; k < p->columnnum; k++)
				mul->matrix[i][j] += p->matrix[i][k] * q->matrix[k][j];
		}
	}
}