#include "oj.h"
/*
����: �������
    
����: MatrixA,MatrixB
    
���: MatrixC

����: 0
     
*/

int matrix(int **MatrixA, int **MatrixB, int **MatrixC, int N)
{
	int *ma = (int *)MatrixA, *mb = (int *)MatrixB, *mc = (int *)MatrixC;

	if (!ma || !mb || !mc)
		return -1;

	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			*(mc + i*N + j) = 0;
			for (int k = 0; k < N; k++)
				*(mc + i*N + j) += *(ma + i*N + k) * *(mb + k*N + j);
		}
	}

	return 0;
}
