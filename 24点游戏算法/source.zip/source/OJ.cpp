/******************************************************************************

  Copyright (C), 2001-2013, Huawei Tech. Co., Ltd.

 ******************************************************************************
  File Name     : 
  Version       : 
  Author        : 
  Created       : 2013/03/12
  Last Modified :
  Description   : 
  Function List :
              
  History       :
  1.Date        : 2013/03/12
    Author      : 
    Modification: Created file

******************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <vector>
#include <sstream>
#include <math.h>

double BinOperate(double a, double b, int op)
{
    switch (op) {
    case 0: return a + b;
    case 1: return a * b;
    case 2: return a - b;
    case 3: return a / b;
    case 4: return b - a;
    case 5: return b / a;
    }
}

double Compute(double a, double b, double c, double d, int i, int j, int k)
{
    return BinOperate(BinOperate(BinOperate(a, b, i), c, j), d, k);
}

void Print(double a, double b, double c, double d, int i, int j, int k)
{
    char ops[] = "+*-/-/";
    std::ostringstream oss;
    oss << "(";
    if (i < 4) {
        oss << a << " " << ops[i] << " " << b;
    } else {
        oss << b << " " << ops[i] << " " << a;
    }
    oss << ")";
    std::string ss = oss.str();
    oss.clear();
    oss.str("");
    oss << "(";
    if (j < 4) {
        oss << ss << " " << ops[j] << " " << c;
    } else {
        oss << c << " " << ops[j] << " " << ss;
    }
    oss << ")";
    ss = oss.str();
    oss.clear();
    oss.str("");
    oss << "(";
    if (k < 4) {
        oss << ss << " " << ops[k] << " " << d;
    } else {
        oss << d << " " << ops[k] << " " << ss;
    }
    oss << ")";
    ss = oss.str();
    std::cout << ss << std::endl;
}

bool Game24Points(int a, int b, int c, int d)
{
    double data[4];
    data[0] = a; data[1] = b; data[2] = c; data[3] = d;
    std::sort(data, data+4);

    char op[6] = {0, 1, 2, 3, 4, 5};

    do {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                for (int k = 0; k < 6; k++) {
                    double re = Compute(data[0],data[1], data[2], data[3], i, j, k);
                    if ((fabs(re - 24) < 1e-6)) {
                        //Print(data[0],data[1], data[2], data[3], i, j, k);
                        return true;
                    }
                }
            }
        }
    } while (std::next_permutation(data, data+4));

	return false;
}

