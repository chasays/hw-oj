#ifndef __OJ_H__
#define __OJ_H__

int GetMinPeriod(char *inputstring);

#endif
