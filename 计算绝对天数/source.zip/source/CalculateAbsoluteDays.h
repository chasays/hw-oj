#ifndef _CALCU_ABS_H
#define _CALCU_ABS_H



int CalculateAbsoluteDays (int year, char month, char day);

#endif
