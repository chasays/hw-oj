/******************************************************************************

Copyright (C), 2001-2011, Huawei Tech. Co., Ltd.

******************************************************************************
File Name     :
Version       :
Author        :
Created       : 2012/3
Last Modified :
Description   :
Function List :

History       :
1.Date        : 2012/3
Author      :
Modification: Created file

******************************************************************************/
#include <string.h>

#include <iostream> 

using namespace std; 

/*****************************************************************************
Description    :�����������
Input Param   : char year�����
                char month���·�
                char day�� ����
Output Param  : ��
Return Value   : �������������
*****************************************************************************/
int CalculateAbsoluteDays (int year, char month, char day)
{
	int maxday[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	int result = 0;

	if ((year % 100 != 0 && year % 4 == 0) || year % 400 == 0)
		maxday[1] = 29;

	if (year<1 || year>10000)
		return 0;
	if (month<1 || month>12)
		return 0;

	if (day<1 || day>maxday[month - 1])
		return 0;

	for (int i = 0; i<month - 1; i++)
		result += maxday[i];
	result += day;

	return result;
}

