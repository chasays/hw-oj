/******************************************************************************

Copyright (C), 2001-2011, Huawei Tech. Co., Ltd.

******************************************************************************
File Name     :
Version       :
Author        :
Created       : 2012/7
Last Modified :
Description   :
Function List :

History       :
1.Date        : 2012/7
Author      :
Modification: Created file

******************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "memory.h"
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

bool reverseCmp(const char &c1, const char &c2)
{
	return c1 > c2;
}

/*****************************************************************************
Description   : ����ת��
Input Param   : pInput �����ļ��׵�ַ			    
Output Param  : pOutput��������׵�ַ
Return Value  : �ɹ�����0��ʧ�ܷ���-1���磺���ݴ���
*****************************************************************************/
int iDataConvert(FILE *pInput,char *pOutput)
{
	vector<string> sv;
	char line[1000];
	while (fgets(line, sizeof(line), pInput)) {
		string sl(line);
		sl.erase(sl.end() - 2, sl.end());
		int len = sl.length() / 2;
		sort(sl.begin(), sl.begin() + len, reverseCmp);
		sort(sl.end() - len, sl.end());
		sv.push_back(sl);
	}

	string sc;
	for (int i = 0; i < sv.size(); i++) {
		sc += sv[i];
	}

	strcpy(pOutput, sc.c_str());
    return 0;
}