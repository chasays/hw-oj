#ifndef _HOST_NAME_H
#define _HOST_NAME_H



int iDataConvert(FILE *pInput, char *pOutput);

#endif
