#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <sstream>
#include "oj.h"

using namespace std;

void digit_multiply(char a, char b, char c, char &re, char &carry)
{
    // '0' ~ '9', a,b为乘数，c为进位，re为结果个位，carry为结果进位
    char z = '0';
    int m = (a-z) * (b-z) + (c-z);
    re = m % 10 + z;
    carry = m / 10 + z;
}

void n_1_mulitply(string sa, char b, string &sc)
{
    char c = '0';
    int la = sa.length();
    string scr;
    for (int i = 0; i < la; i++) {
        char re, carry;
        digit_multiply(sa[la-1-i], b, c, re, carry);
        scr.push_back(re);
        c = carry;
    }
    scr.push_back(c);
    sc = string(scr.rbegin(), scr.rend());
    while (!sc.empty()) {
        if (sc[0] != '0')
            break;
        sc.erase(0, 1);
    }
    if (sc.empty())
        sc.push_back('0');
    //cout << sa << " " << b << " " << sc << endl;
}

void digit_add(char a, char b, char c, char &re, char &carry)
{
    // '0' ~ '9', a,b为加数，c为进位，re为结果个位，carry为结果进位
    char z = '0';
    int m = (a-z) + (b-z) + (c-z);
    re = m % 10 + z;
    carry = m / 10 + z;
}

void add(string sa, string sb, string &sc)
{
    int la = sa.length();
    int lb = sb.length();
    int ls = la<lb ? la:lb;
    if (la > ls) {
        sb.insert(0, la-ls, '0');
    } else if (lb > ls) {
        sa.insert(0, lb-ls, '0');
    }
    int len = sa.length();

    char c = '0';
    string scr;
    for (int i = 0; i < len; i++) {
        char re, carry;
        digit_add(sa[len-1-i], sb[len-1-i], c, re, carry);
        scr.push_back(re);
        c = carry;
    }
    scr.push_back(c);
    sc = string(scr.rbegin(), scr.rend());
    while (!sc.empty()) {
        if (sc[0] != '0')
            break;
        sc.erase(0, 1);
    }
    if (sc.empty())
        sc.push_back('0');
}

int multiply (const std::string strMultiplierA, const std::string strMultiplierB, std::string &strRst)
{
    string sa = strMultiplierA;
    string sb = strMultiplierB;
    if (sa.empty() || sb.empty())
        return -1;

    //int la = sa.length();
    int lb = sb.length();
    strRst = "0";
    for (int i = 0; i < lb; i++) {
        string sc;
        n_1_mulitply(sa, sb[lb-1-i], sc);
        sc.append(i, '0');
        string sd = strRst;
        add(sc, sd, strRst);
    }

    return 0;
}

void CalcNN(int n, char *pOut)
{
    if (n < 0 || !pOut)
    {
        pOut[0] = '0';
        pOut[1] = '\0';
        return;
    }

    int sum = 1;
    int i = 1;
    for (; i <= 12 && i <= n ; i++) {
        sum *= i;
    }
    stringstream ss;
    ss << sum;
    string c;
    ss >> c;
    if (n > 12) {
        for (; i <= n; i++) {
            string a = c;
            ss.clear();
            ss << i;
            string b;
            ss >> b;
            multiply(a, b, c);
        }
    }
    strcpy(pOut, c.c_str());

	return;
}
