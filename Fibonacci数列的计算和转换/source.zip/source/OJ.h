#ifndef __OJ_H__
#define __OJ_H__





int GetExtFibonacci(int first , int second, int num);
int CalcTotalValueOfExtFibonacci(int first , int second, int num);

#endif
