/******************************************************************************

  Copyright (C), 2001-2011, Huawei Tech. Co., Ltd.

 ******************************************************************************
  File Name     : 
  Version       : 
  Author        : 
  Created       : 2012/03/12
  Last Modified :
  Description   : 
  Function List :
              
  History       :
  1.Date        : 2012/03/12
    Author      : 
    Modification: Created file

******************************************************************************/
#include <stdlib.h>
#include <stdexcept>

#define null 0
#define MAXSIZE 50

struct strlnode
{
	int data;
	struct strlnode *plast;
	struct strlnode *pnext;
};

void create(struct strlnode **p, int x)  /*����˫����(��ͷ�ڵ�)*/
{
	struct strlnode *q;

	q = (struct strlnode *)malloc(sizeof(struct strlnode));
	q->data = x;
	q->plast = null;
	q->pnext = null;

	*p = q;

	return;
}

int getnodenum(struct strlnode **p)  /*��ȡ�����нڵ����*/
{
	int nodenum = 0;
	struct strlnode *s = *p;
	while (s != null) {
		nodenum++;
		s = s->pnext;
	}
	return nodenum;
}

void insertnode(struct strlnode **p, int i, int x) /* ��������i��λ�ò������ݵ���x�Ľڵ� */
{
	int nodenum = getnodenum(p);
	if (i > nodenum || i < 0)
		throw new std::range_error("range error");
		// return;
	
	struct strlnode *node = (struct strlnode *)malloc(sizeof(struct strlnode));
	node->data = x;

	struct strlnode *s = *p;
	node->plast = null;
	for (int j = 0; j < i; j++) {
		node->plast = s;
		s = s->pnext;
	}

	node->pnext = s;	
	if (node->plast)
		node->plast->pnext = node;
	if (s)
		s->plast = node;

	if (i == 0)
		*p = node;
}

void deletenode(struct strlnode **p, int i) /* ɾ�������е�i���ڵ� */
{
	int nodenum = getnodenum(p);
	if (i >= nodenum || i < 0)
		throw new std::range_error("range error");
		// return;

	struct strlnode *s = *p;
	for (int j = 0; j < i; j++) {
		s = s->pnext;
	}

	if (s->pnext)
		s->pnext->plast = s->plast;
	if (s->plast)
		s->plast->pnext = s->pnext;
	else
		*p = s->pnext;

	delete s;
}

void bignumberplus(struct strlnode **plus, struct strlnode **p, struct strlnode **q) /* ʹ������ʵ�ִ�������� */
{
	struct strlnode *s = *p;
	struct strlnode *t = *q;
	while (s->pnext)
		s = s->pnext;
	while (t->pnext)
		t = t->pnext;
	
	int c = 0;
	while (s || t) {
		int ss = 0, tt = 0;
		if (s) {
			ss = s->data;
			s = s->plast;
		}
		if (t) {
			tt = t->data;
			t = t->plast;
		}
		int sum = ss + tt + c;
		c = sum / 10;
		int r = sum % 10;
		insertnode(plus, 0, r);
	}
	if (c > 0)
		insertnode(plus, 0, c);
	
	deletenode(plus, getnodenum(plus) - 1);
}


void readtolnode(struct strlnode **p, int *a, int size)  /* ������д�������У������е����ݵ��Ⱥ�˳��������е�˳��Ҫ����һ�� */
{
	int j = 0;
	int data = 0;
	struct strlnode *s = *p;

	s->data = *(a + (size-1));

	for(j = 2; j < (size+1); j++)
	{
		data = *(a + (size-j));
		insertnode(p, 0, data);
	}

	return;
}


void writetosqlist(int *a, struct strlnode *p)  /* ������д�������У������е����ݵ��Ⱥ�˳��������е�˳��Ҫ����һ�� */
{
	int j = 0;
	struct strlnode *s = p;

	while(s != null)
	{
		*(a + j) = s->data;
		s = s->pnext;
		j++;
	}

	return;
}






