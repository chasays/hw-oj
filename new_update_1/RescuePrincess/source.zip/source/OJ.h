#ifndef __OJ_H__
#define __OJ_H__

int SSavep(char *visited, int t, int n, int m);

#endif
