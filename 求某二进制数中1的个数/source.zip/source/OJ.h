#ifndef __OJ_H__
#define __OJ_H__

int GetCount(unsigned int num);


#endif
