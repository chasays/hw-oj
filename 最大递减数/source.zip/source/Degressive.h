#ifndef _PEPOLE_NAME_H
#define _PEPOLE_NAME_H



int getMaxDegressiveNum (int num);




#endif
