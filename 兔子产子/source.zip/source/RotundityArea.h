#ifndef __OJ_H__
#define __OJ_H__


void OutputRotundityArea(float* pRotondityArea, int nCount);

#endif
